import matplotlib.pyplot as plt

# Your data (replace with your own data)
categories = ["Category A", "Category B", "Category C", "Category D"]
values = [15, 30, 10, 25]

# Sort data in descending order
sorted_data = sorted(zip(categories, values), key=lambda x: x[1], reverse=True)
categories, values = zip(*sorted_data)

# Create a blueish color scheme
colors = ['#1f77b4', '#aec7e8', '#ff7f0e', '#ffbb78']

# Create the bar plot
fig, ax = plt.subplots()
bars = ax.bar(categories, values, color=colors)

# Rotate the labels to 45 degrees
plt.xticks(rotation=45, ha='right')

# Customize other plot settings as needed (e.g., titles, labels, etc.)

# Show the plot
plt.show()
